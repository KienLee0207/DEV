#include<stdio.h>
#include<string.h>
int main()
{
	char Ten[16];
	
	    printf("nhap 1 chuoi:");
	gets(Ten);
    	printf("chuoi vua nhap:");
	
	puts(Ten);/*in ra chuoi vua nhap*/
return 0;
	
}
