#include <stdio.h>
void main()
{
	int num1,num2;
	 num2=0;
	 
	 do
	 {
	 	   printf("\n enter number:");
	 	   scanf("%d",&num1);
	 	   printf("No.is %d",num1);
	 	   num2++;
	 } while ( num1 != 0);
	 printf("the total number enter ware%d\n",--num2);
	 
	

}
