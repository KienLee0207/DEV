#include <stdio.h>
int main(int argc, char const *argv[])
{
	/* code */
	int basicsalary,DA,HRA,TA,others,PF,IT;
	int sum;
	
	   printf("basic salary:");
	scanf("%d",&basicsalary);
	
    	printf("\nDA :");
	scanf("%d",&DA);
	
	     printf("\nHRA:");
	scanf("%d",&HRA);
	
	      printf("\nTA:");
    scanf("%d",&TA);
    
            printf("\nothers:");
    scanf("%d",&others);
    
           printf("\nPF :");	
    scanf("%d",&PF);
    
             printf("\nIT :");
    scanf("%d",&IT);
    sum=basicsalary + DA + HRA + TA + others - (PF + IT);
   printf(" Net salary=BasicSalary + DA + HRA + TA + Others - (PF + IT)=%d",sum);
           


	return 0;
}
