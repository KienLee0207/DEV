#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void)
 {
	int a,b,c;
	int sum;
		printf("a=");
	scanf("%d",&a);
	
 		printf("b=");
	scanf("%d",&b);
	
	sum =c= --a +b;
		printf("c=%d + %d =%d\n",a,b,sum);
		
	sum =c = a-- + b;
		printf("c= %d + %d=%d\n",a,b,sum);
		return 0;
		 
	
}
	
