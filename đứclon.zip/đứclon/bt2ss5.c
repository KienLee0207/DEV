#include <stdio.h>
 int swap(int a, int b);
 int main()
 {
 int x = 23, y =21;
 			printf("gia tri ban dau cua x = %d, y = %d\n ",x,y);
 
 swap (x,y);
 
 			printf("gia tri sau cua x= %d\t, y = %d\n",x,y);
   return 0;
   
 }
 int swap(int a, int b)
 {
 	int clu;
 	clu=a;
 	a= b - 2;
 	b=clu;
 	
 }
