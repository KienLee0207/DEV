#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
 	int age;
	char name[30];
	char gender;
	
   			printf("what your name?\n");
	gets(name);
	
 			printf("how old are you?\n");
	scanf("%d",&age);
	
			printf("you are girl or boy?\n1 is girl and 2 is boy\n1 or 2 ? :");	
			fflush(stdin);
    scanf("%c",&gender);
    
	switch(gender)
	{
		case '1' :
			printf("you can say : I LOVE YOU?(Y or N)\n\t\t");
		scanf("%s",&gender);
		if(gender=='Y'){
		
		   	printf("\t\t\t\t\t And I LOVE YOu !! <3");
		
	   }else
			printf("\t\t\t\t\t fuck !! <3");			
			break;
		case '2' :
			printf("next man :)))");
			break;
			}
		return 0;

}
