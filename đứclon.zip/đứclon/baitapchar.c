#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int age;
	char name[30];
	char gender;
	
	   printf("enter your name:");
	gets(name);
	   printf("enter your age:");
	scanf("%d",&age);
     	printf("enter your gender (n la con gai m la con trai )");
     	fflush(stdin);
	scanf("%c",&gender);

		if(age<18)
		printf("my name kien\n");
		
		if(age >50)
		printf("my name duc\n");
		
		printf("%c");
		
		
	switch(gender){
		case 'n':
		printf("\n hello girl");
		break;
		case 'm':
		printf("\n hello boy");
		break;
	}	
	return 0;
}
