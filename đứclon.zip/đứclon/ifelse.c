#include <stdio.h>
void main()
{
	
 int num,res;
 printf("enter a number :");
scanf("%d",&num);

res = num % 2;
if (!res)
{
	printf("then number is even");
	
} else
	printf("then number is odd");
}
