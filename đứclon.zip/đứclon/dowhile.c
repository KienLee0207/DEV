#include <stdio.h>
int main()
{
char operator;
int a,b;
	printf("a=");
	scanf("%d",&a);	
	printf("b=");
	scanf("%d",&b);
 printf("chon operator (+,-,*,/):");
 fflush(stdin);
 scanf("%c",&operator);
 switch(operator){/* ham chon truong hop*/
 	case '+':/* truong hop*/
 	printf("%d+%d=%d",a,b,a+b);
 	break;/* ket thuc ham*/
 	case '-' :
 	printf("%d-%d=%d",a,b,a-b);
 	break;
 }
 	return 0;
 } 	
