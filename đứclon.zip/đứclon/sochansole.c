void main()
{	
 int i, j , max;
 printf("please enter  the maxium value \n");
 printf("for which a table can be printed");
 scanf("%d",&max);
 
  for(i= 0, j= max; i <= max; i++,j--) 
  printf("%d+ %d = %d",i,j,i+j);
  return 0;
}		
